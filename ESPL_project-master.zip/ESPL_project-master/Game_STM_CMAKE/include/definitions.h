
#ifndef TYPES_H
#define TYPES_H

/*
 * FreeRTOS definitions
 */

#define PI 3.14159265
#define STACK_SIZE 2000
#define LASER_MAX 50
#define FIRE_MAX 2
#define FIRE_OPP_MAX 50

/*
 * Display definitions
 */

static const uint16_t displaySizeX = 320,
		      	  	  displaySizeY = 240;

/*
 * Ship definitions
 */

static const uint16_t SHIP_SIZE=30; // ship height in pixels
static const uint16_t SHIP_TURN_SPD=360; // turn speed in degrees per second
static const uint16_t SHOW_CENTRE_DOT=0; // show or hide ship's centre dot
static const uint16_t SHIP_BLINK_DUR = 0.1; // duration in seconds of a single blink during ship's invisibility
static const uint16_t SHIP_EXPLODE_DUR = 0.5; // duration of the ship's explosion in seconds
static const uint16_t SHIP_INV_DUR = 5; // duration of the ship's invisibility in seconds
static const uint16_t SAUCER_THRUST=70; // acceleration of the saucer in pixels per second
static const uint16_t CONST=50;


struct thrust
{ 		float x;
		float y;
};

struct Ship
{
	float x;
	float y;
    int r ;
    float angle;// convert to radians
} ;

/*
 * lives and levels
 */
static const uint16_t GAME_LIVES = 3; // starting number of lives


/*
 * bullets definitions
 */
static const uint16_t LASER_DIST = 0.6; // max distance laser can travel as fraction of screen width
static const uint16_t LASER_EXPLODE_DUR = 0.1; // duration of the lasers' explosion in seconds
static const uint16_t LASER_SPD = 200; // speed of lasers in pixels per second

 struct laser
 {
 float x;
 float y;
 float xv;
 float yv;
 int expired;

 } ;

 /**
  * Fire from Saucer definitions
  */


 struct fire
 {
 float x;
 float y;
 float xv;
 float yv;
 int expired;

 } ;
/*
 * Asteroids definitions
 */

static const uint16_t ROID_NUM=23; // starting number of asteroids
static const uint16_t ROID_SIZE=50; // starting size of asteroids in pixels
static const uint16_t ROID_SPD=70; // max starting speed of asteroids in pixels per second
static const uint16_t ROID_VERT=10; // average number of vertices on each asteroid
static const uint16_t ROID_JAG=0.8; // jaggedness of the asteroids (0 = none, 1 = lots)

struct roid {
				float x;
	            float y;
                float offs[30];
                int vert;
                float a ; //random angle in radians
                float xv;
                float yv;
                float r ;
                int dead;
 } ;


/**
 * Saucer definitions
 */
// max starting speed of the saucer in pixels per second
static const uint16_t SAUCER_SPD=70;
static const uint16_t SAUCER_OPP_SPD=100;

struct Saucer {

	float xv;
	float yv;
	float r1,r2;
	float x,y;// center of the saucer
	int dead;
	int a;
	struct thrust thrust;


 } ;

/*
 * States
 */
#define START_MENU 1
#define START_GAME 2
#define PAUSE_GAME 3
#define EXIT_GAME 4
#define END_GAME 5
#define CHEATS 6
#define HIGH_SCORE 7

#define STATE_ONE  1
#define STATE_TWO  2
#define STATE_THREE 3
#define STATE_FOUR 4
#define STATE_FIVE 5
#define STATE_SIX 6
#define STATE_SEVEN 7

/*
 * Game struct definitions
 */
struct highscore {
	int SingleHighScore;
	int MultiHighScore;

};
typedef enum {SINGLE_MODE, MULTIPLAYER_MODE} Mode;

struct Game
{

    int ShipLives;
    int ShipScore;
    int SaucerScore;
    int SaucerLives;

    struct Ship ship;
    struct highscore HighScore;
    struct Saucer saucer;
    unsigned char value,value1;
    Mode mode;
    int  level;
	int16_t roidsNumber;
	int b;
	int cheats;
};

/*
 * Button definitions
 */
struct coord {
	uint8_t x;
	uint8_t y;
};

typedef struct{
	 struct coord joystick;
		    unsigned char A;
		    unsigned char B;
		    unsigned char C;
		    unsigned char D;
		    unsigned char E;
		    unsigned char K;
		    unsigned char active;
		    unsigned char saucerPlayer;
		    unsigned char shipPlayer;
		    unsigned char randValue;
		    unsigned char randValue1;
	unsigned char server;
} buttons;

typedef struct{
    uint8_t currentState;
    uint8_t lastState;
} Button;

// Start and stop bytes for the UART protocol
static const uint8_t startByte = 0xAA, stopByte = 0x55;

#define BUTTON_QUEUE_LENGTH 20
#define STATE_QUEUE_LENGTH 1

#define BUTTON_PRESSED         1
#define BUTTON_UNPRESSED       0




#endif
