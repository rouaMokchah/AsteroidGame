#include "includes.h"

/** @brief this file includes all the functions that are used
 * to draw the saucer, draw the ship , thrust them, shoot und check for the
 * collision.
 */

/** Updates the angle of the ship
     *  @param game struct
	 *  @param x and y coordinates of the joystick.
     */
void updateShipAngle(struct Game *game, int16_t joyX,int16_t joyY){
	static float previous;
				if(joyX>100 && joyY>=100)
					{
						game->ship.angle = 45*(PI/180);
						previous=game->ship.angle;
					}

					else if (joyX>100 && joyY <-100)
						{
						game->ship.angle = -45*(PI/180);
						previous=game->ship.angle;
						}

					else if (joyX<=10 && joyX>=-10 && joyY<-127){
						game->ship.angle = -90*(PI/180);
						previous=game->ship.angle;
					}

					else if(joyY>100 && joyX>-130 && joyX<-50){
						game->ship.angle = -225*(PI/180);
						previous=game->ship.angle;
					}

					else if(joyY<=-100 && joyX<=-100){
						 game->ship.angle = 225*(PI/180);
						 previous=game->ship.angle;
					}

					else if (joyX<-100 && joyY>=-10 && joyY<=10){
						game->ship.angle = 180*(PI/180);
						 previous=game->ship.angle;
					}

					else if (joyX>100 && joyY<=10 && joyY>=-10) {
						game->ship.angle = 0;
						previous=game->ship.angle;
					}

					else if(joyX<=10 && joyX>=-10 && joyY >= 120){
						game->ship.angle = 90*(PI/180);
						previous=game->ship.angle;
					}
					else
						game->ship.angle=previous;
}

/** Updates the angle of the saucer
     *  @param game struct
	 *  @param x and y coordinates of the joystick.
     */
void updateSaucerAngle(struct Game *game, int16_t joyX,int16_t joyY){
	static float previous;
	if(joyX>100 && joyY>=100)
						{
							game->saucer.a = 45*(PI/180);
							previous=game->saucer.a;
						}

						else if (joyX>100 && joyY <-100)
							{
							game->saucer.a = -45*(PI/180);
							previous=game->saucer.a;
							}

						else if (joyX<=10 && joyX>=-10 && joyY<-127){
							game->saucer.a = -90*(PI/180);
							previous=game->saucer.a;
						}

						else if(joyY>100 && joyX>-130 && joyX<-50){
							game->saucer.a= -225*(PI/180);
							previous=game->saucer.a;
						}

						else if(joyY<=-100 && joyX<=-100){
							game->saucer.a = 225*(PI/180);
							 previous=game->saucer.a;
						}

						else if (joyX<-100 && joyY>=-10 && joyY<=10){
							game->saucer.a = 180*(PI/180);
							 previous=game->saucer.a;
						}

						else if (joyX>100 && joyY<=10 && joyY>=-10) {
							game->saucer.a = 0;
							previous=game->saucer.a;
						}

						else if(joyX<=10 && joyX>=-10 && joyY >= 120){
							game->saucer.a = 90*(PI/180);
							previous=game->saucer.a;
						}
						else
							game->saucer.a=previous;

}

/**Initializes new Game
 * during the multiplayer mode.
    *  @param struct game.
    *    @param struct roids.
    */
void  newGame(struct Game *game,struct roid roids[]) {
	if(!game->cheats){
			game->level = 0;
		    game->ShipScore=0;
		}

		//reset the lives,scores
	    game->ShipLives = GAME_LIVES;
	    game->SaucerLives = GAME_LIVES;
	    game->SaucerScore=0;
		//saucer alive
	    game->saucer.dead=0;
		//draw the ship
	    game->ship.x=displaySizeX/2;
	    game->ship.y=displaySizeY/2;
	    game->ship.angle=90*(PI/180);
	newShip(game,game->ship.x,game->ship.y,game->ship.angle,White);
        }

/**Initializes new Level
 * during the multiplayer mode.
    *  @param struct game.
    *    @param struct roids.
    */
void  newLevel(struct Game *game,struct roid roids[]) {
	game->level=game->level+1;
        }

/** Calculates the distance between different objects.
    */
float distanceBetweenPoints(float x1,float y1,float x2,float y2){

	float distance=sqrt ((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	return distance;

}//distanceBetweenPoints

/** Intializes and draws the saucer.
     *  @param struct game.
	 * @param integer s to specify which saucer to draw.
	 * if s=1, mutiplayer mode
	 * if s=0, single player mode.
     */

void newSaucer(struct Game *game, int s ){

	if (!game->saucer.dead){
	// These constants are used to draw 2 different types of saucers
	float c1=0,c2=0,c3=0,c4=0;
	float x1=-1,x2=-1,x3=-1,x4=-1,x5=-1,x6=-1,x7=-1;
	float y1=-1,y2=-1,y3=-1,y4=-1,y5=-1,y6=-1,y7=-1;

	if (s==0) {
		//Single player mode, bigger saucer comes
		 c1=game->saucer.r2/2;
		 c2=game->saucer.r1/2;
		 c3=game->saucer.r2;
		 c4=game->saucer.r1;
	}
	else if (s==1){
		//multiplayer mode, smaller saucer comes
		 c1=game->saucer.r2/4;
		 c2=game->saucer.r1/4;
		 c3=game->saucer.r2/2;
		 c4=game->saucer.r1/2;
	}

		x1= game->saucer.x-c1;
		y1= game->saucer.y+c1;
		x3= game->saucer.x-c3;
		y3= game->saucer.y;
		x2= game->saucer.x+c1;
		y2= game->saucer.y+c1;
		x4= game->saucer.x+c3;
		y4= game->saucer.y;
		x5= game->saucer.x-c1;
		y5= game->saucer.y-c2;
		x6= game->saucer.x+c1;
		y6= game->saucer.y-c2;
		x7= game->saucer.x;
		y7= game->saucer.y-c4;

		gdispDrawLine(x1,y1,x2,y2,White);
		gdispDrawLine(x1,y1,x3,y3,White);
		gdispDrawLine(x2,y2,x4,y4,White);
		gdispDrawLine(x3,y3,x4,y4,White);
		gdispDrawLine(x3,y3,x5,y5,White);
		gdispDrawLine(x6,y6,x5,y5,White);
		gdispDrawLine(x6,y6,x4,y4,White);
		gdispDrawLine(x6,y6,x7,y7,White);
		gdispDrawLine(x5,y5,x7,y7,White);
	}

}//newBigSaucer

/*
 * Creates the big roids for each level.
 *  @param struct game.
 *   @param struct roids.
 *    @param value for srand so that during the multiplayer
 *    game both screen have the same shapes of roids.
 */
void  createAsteroid(struct roid roids[],struct Game *game,int level,unsigned char value){

	srand(value);

	 roids[0].x = (rand()/(double)RAND_MAX) *displaySizeX;
	 roids[0].y = (rand()/(double)RAND_MAX) *displaySizeY;
     roids[0].vert= (rand() % 7) + 3;
	 roids[0].a= (rand()/(double)RAND_MAX)* PI * 2;
	 roids[0].r= ROID_SIZE/2;
	 roids[0].dead= 0;
	 roids[0].xv=ROID_SPD/ CONST ;
	 roids[0].yv=ROID_SPD/ CONST ;
	for (int  j = 0; j < roids[0].vert; j++) {
	roids[0].offs[j]=((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);
		}

		for (int i = 1; i < ROID_NUM-20+level; i++) {
				 	 	 // give each asteroids random x and y coordinates
						 // make sure that they don't smash the ship
					  do {
					      roids[i].x = (rand()/(double)RAND_MAX) *displaySizeX;
					      roids[i].y = (rand()/(double)RAND_MAX) *displaySizeY;
					     }
					while (distanceBetweenPoints(roids[i].x,roids[i].y,game->ship.y,game->ship.x) < (roids[i].r + game->ship.r)
							&& distanceBetweenPoints(roids[i-1].x,roids[i-1].y,roids[i].x,roids[i].y) < (roids[i].r + roids[i-1].r));
					     //Ecken vom Astroids
					     // Number between 6 and 13 (rand() % (max + 1 - min)) + min
					        roids[i].vert= (rand() % 7) + 3;

					     // get a random angle in radians
					       roids[i].a= (rand()/(double)RAND_MAX)* PI * 2;
					     // get the radius
					       roids[i].r= ROID_SIZE/2;
					       roids[i].dead= 0;

					   roids[i].xv=ROID_SPD/ CONST ;
					   roids[i].yv=ROID_SPD/ CONST ;
					   //roids[i].yv=(rand()/(double)RAND_MAX)*ROID_SPD/ CONST ;

					   //create the vertex offset array, this will change the vertex location
					   //vertex will be one radius away from the center
					    for (int  j = 0; j < roids[i].vert; j++) {

					    roids[i].offs[j]=((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);

					   }
	   }

		for (int i = 1; i < ROID_NUM-20+(game->level); i++){
			for (int j = i+1; j < ROID_NUM-20+(game->level); j++){
				if (distanceBetweenPoints(roids[i].x,roids[i].y,roids[j].x,roids[j].y) < (roids[j].r + roids[i].r)){
					 do {
						  roids[i].x = (rand()/(double)RAND_MAX) *displaySizeX;
						  roids[i].y = (rand()/(double)RAND_MAX) *displaySizeY;
						 }
					while (distanceBetweenPoints(roids[i].x,roids[i].y,game->ship.y,game->ship.x) < (roids[i].r + game->ship.r)
							&& distanceBetweenPoints(roids[i-1].x,roids[i-1].y,roids[i].x,roids[i].y) < (roids[i].r + roids[i-1].r));
				}
			}
		}
}

/*
 * Creates the laser struct
 *  @param struct game.
 *   @param struct lasers.
 */
void createLaser(struct Game *game, struct laser lasers[]){

	int k=0;

 	 while(lasers[k].expired==0 && (k< LASER_MAX -1))
 	 {
 		 k=k+1;
 	 }

	lasers[k].x=game->ship.x + 4 / 3 * game->ship.r * cos(game->ship.angle);
	lasers[k].y=game->ship.y - 4 / 3 * game->ship.r * sin(game->ship.angle);
	lasers[k].expired=0;
	lasers[k].xv= LASER_SPD * cos(game->ship.angle) / CONST;
	lasers[k].yv= -1*LASER_SPD * sin(game->ship.angle) / CONST;

}//CREATELASER

/*
 * Draws the laser when the button is pressed
 *   @param struct lasers.
 */
void drawLaser( struct laser lasers[]){

		  for (int i = 0; i < LASER_MAX  ; i++) {

	if (lasers[i].x <displaySizeX && lasers[i].y < displaySizeY && !lasers[i].expired) {
		// move the laser
		gdispDrawCircle(lasers[i].x,lasers[i].y, SHIP_SIZE / 15,White);
		lasers[i].x +=lasers[i].xv;
		lasers[i].y +=lasers[i].yv;
		}
	else
		lasers[i].expired=1;
	}
}//drawLaser

void createFireFromSaucer(struct Game *game,int s, struct fire counter_fires[]){

		int k=0;

	 	// if the opp saucer is selected
	 	if (s==1){
	 		 while(counter_fires[k].expired==0 && (k< FIRE_OPP_MAX -1))
	 			 	 {
	 			 		 k=k+1;
	 			 	 }


	 		counter_fires[k].expired=0;
	 		counter_fires[k].x=game->saucer.x + 4 / 3 * game->saucer.r2 * cos(game->saucer.a);
	 		counter_fires[k].y=game->saucer.y - 4 / 3 * game->saucer.r2 * sin(game->saucer.a);
	 		counter_fires[k].xv= LASER_SPD * cos(game->saucer.a) / CONST;
	 		counter_fires[k].yv= -1*LASER_SPD * sin(game->saucer.a) / CONST;
	 	}
	 	// if big
	 	else if (s==0){
	 		 while(counter_fires[k].expired==0 && (k< FIRE_MAX -1))
	 			 	 {
	 			 		 k=k+1;
	 			 	 }

	 		counter_fires[k].expired=0;
	 		counter_fires[k].x=game->saucer.x;
	 		counter_fires[k].y=game->saucer.y+game->saucer.r1;
	 		counter_fires[k].xv= 0;
	 		counter_fires[k].yv= 2*counter_fires[k].y/ CONST;
	 	}


}//createFireFromSaucer

void drawFire(struct fire counter_fires[],struct Game *game,int s){
	if (s==1){
		for (int i = 0; i < FIRE_OPP_MAX  ; i++) {
						if (counter_fires[i].x <displaySizeX && counter_fires[i].y < displaySizeY && !counter_fires[i].expired && !game->saucer.dead) {
							// move the laser
							gdispFillCircle(counter_fires[i].x,counter_fires[i].y,1,Gray);
							counter_fires[i].x +=counter_fires[i].xv;
							counter_fires[i].y +=counter_fires[i].yv;

							}
						else
							counter_fires[i].expired=1;
						}
	}
	else if (s==0){
		for (int i = 0; i < FIRE_MAX  ; i++) {
				if (counter_fires[i].x <displaySizeX && counter_fires[i].y < displaySizeY && !counter_fires[i].expired && !game->saucer.dead) {
					// move the laser
					gdispFillCircle(counter_fires[i].x,counter_fires[i].y,1,Gray);
					counter_fires[i].x +=counter_fires[i].xv;
					counter_fires[i].y +=counter_fires[i].yv;

					}
				else
					counter_fires[i].expired=1;
				}

	}

}//drawFire



/** Creates new ship.
 * @param struct game.
 * @param x,y for the position of the center of the ship
 * @param color which is usual white
 */

void newShip(struct Game *game,float x,float y,float a,color_t color){

	float x1= x + 11 / 3 * game->ship.r * cos(a);
	float y1= y - 11 / 3 * game->ship.r * sin(a);
	float x2= x - game->ship.r * (2 / 3 * cos(a) + sin(a));
	float y2= y+ game->ship.r * (2 / 3 * sin(a) - cos(a));
	float x3= x - game->ship.r * (2 / 3 * cos(a) - sin(a));
	float y3= y + game->ship.r * (2 / 3 * sin(a) + cos(a));

	gdispDrawLine(x1,y1,x2,y2,color);
	gdispDrawLine(x1,y1,x3,y3,color);
	gdispDrawLine(x2,y2,x,y-3,color);
	gdispDrawLine(x3,y3,x,y-3,color);

}//NewShip


/** Updates the position of the Saucer.
 * @param struct game.
 */
void moveSaucer (struct Game *game,int s ){

	if(!game->saucer.dead){
	if (s==0){
			game->saucer.xv= SAUCER_SPD/CONST;
			// i set this to zero so that it floats
			game->saucer.yv= 0;

			game->saucer.x += game->saucer.xv;
			game->saucer.y += game->saucer.yv;
	}
	else if (s==1){

		game->saucer.thrust.x = SAUCER_OPP_SPD * cos(game->saucer.a) / CONST;
		game->saucer.thrust.y = -1*SAUCER_OPP_SPD * sin(game->saucer.a) / CONST;

		game->saucer.x += game->saucer.thrust.x;
		game->saucer.y += game->saucer.thrust.y;

		game->saucer.x += game->saucer.thrust.x;
		game->saucer.y += game->saucer.thrust.y;

		}

	}

}//moveSaucer

/** Updates the position of the ship.
 * @param struct game.
 */
void thrustShip(struct Game *game,char pressed){
	static double move=4;
	static char stop=0;
if (pressed) {
	game->ship.x += move * cos(game->ship.angle) ;
	game->ship.y -= move * sin(game->ship.angle) ;
	stop=1;
}
else if (stop ){
	move*=0.991;
	game->ship.x += move * cos(game->ship.angle) ;
	game->ship.y -= move * sin(game->ship.angle) ;
}
if((int)move==0){
	move=4;
	stop=0;
}
}

/** Makes the ship and saucer spawn around the display
 * @param struct game.
 */
void handleEdgeOfScreen(struct Game *game)
{
	//handle edge screen of ship
	if (game->ship.x < 0 - game->ship.r)
	{
	game->ship.x = displaySizeX + game->ship.r;
	}
	else if (game->ship.x > displaySizeX + game->ship.r)
	{
		game->ship.x = 0 - game->ship.r;
	}
	if (game->ship.y < 0 - game->ship.r)
	{
	    game->ship.y = displaySizeY + game->ship.r;
	}
	else if (game->ship.y > displaySizeY + game->ship.r)
	{
		game->ship.y = 0 - game->ship.r;
	}

	//handle edge of screen of the saucer
	if (game->saucer.x < 0 - game->saucer.r2 )
	{
		game->saucer.x = displaySizeX + game->saucer.r2;
	}

	else if (game->saucer.x > displaySizeX + game->saucer.r2)
	{
		game->saucer.x = 0 - game->saucer.r2;
	}
	if (game->saucer.y < 0 - game->saucer.r1)
	{
		game->saucer.y = displaySizeY + game->saucer.r1;

	}
	else if (game->saucer.y > displaySizeY + game->saucer.r1)
	{
		game->saucer.y = 0 - game->saucer.r1;
	}

}// handleEdgeOfScreen

// detect ship hits on asteroids
void detectLaser(struct Game *game,struct laser lasers[],struct roid roids[]){

            for (int i = 0; i <  ROID_NUM  ; i++) {
              if(roids[i].dead==0){

                // loop over the lasers
                for (int j = 0; j < LASER_MAX  ; j++) {
                    // detect hits
                   if ( lasers[j].expired==0 && distanceBetweenPoints(roids[i].x,roids[i].y,lasers[j].x,lasers[j].y ) < roids[i].r ) {

                        // destroy the asteroid and expire the laser
                        lasers[j].expired = 1;
                        if(roids[i].r==(ROID_SIZE / 2)){
                        	game->ShipScore=game->ShipScore+500;
                        }else if(roids[i].r==(ROID_SIZE / 4)){
                        	game->ShipScore=game->ShipScore+1000;
                        }
                        destroyroid(game,roids,i);
                        break;
                    }
                }
            }

            }
}

/** Checks for collision between Saucer and roids
 * during the multiplayer mode.
    *  @param struct game.
    *   @param struct fire.
    *    @param struct roids.
    */
void saucerRoid(struct Game *game,struct fire counter_fires[],struct roid roids[]){

            for (int i = 0; i <  ROID_NUM  ; i++) {
              if(roids[i].dead==0){

                // loop over the lasers
                for (int j = 0; j < FIRE_OPP_MAX  ; j++) {
                    // detect hits
                   if ( counter_fires[j].expired==0 && distanceBetweenPoints(roids[i].x,roids[i].y,counter_fires[j].x,counter_fires[j].y ) < roids[i].r ) {

                        // destroy the asteroid and expire the fire
                	   counter_fires[j].expired = 1;
                        if(roids[i].r==(ROID_SIZE / 2)){
                        	game->SaucerScore=game->SaucerScore+500;
                        }else if(roids[i].r==(ROID_SIZE / 4)){
                        	game->SaucerScore=game->SaucerScore+1000;
                        }
                        destroyroid(game,roids,i);
                        break;
                    }
                }
            }

            }
}

/** Checks for collision between laser
	* from the ship and the saucer
     *   @param game struct
	 *   @param laser struct
	 *  @param integer s to specify which saucer to draw.
	 * if s=1, mutiplayer mode
	 * if s=0, single player mode.
     */
int collisionLaserSaucer (struct Game *game,struct laser lasers[], int s){

	int shot=0;
	if(!game->saucer.dead){
	// loop over the lasers
	for (int j = 0; j < LASER_MAX  ; j++) {
		// detect hits
		if ( lasers[j].expired==0 &&
			(distanceBetweenPoints(game->saucer.x,game->saucer.y,lasers[j].x,lasers[j].y )
	            < game->saucer.r1 )) {
//			||distanceBetweenPoints(game->saucer.x,game->saucer.y,lasers[j].x,lasers[j].y ) < game->saucer.r2
			// destroy the saucer and expire the laser
			lasers[j].expired = 1;
			game->ShipScore=game->ShipScore+1000;

			shot=1;

			}
			break;
		}
	}
	return shot;
}//collisionLaserSaucer


/** Checks for collision between fire and ship.
	*@returns 1 if the ship was shot.
	* else 0
    *  @param struct game.
    */
int collisionFireShip (struct Game *game,struct fire counter_fires[],int s){

	int shot=0;
	 if(!game->saucer.dead){

		 if (s==0) { // Single mode
			 for (int i=0;i <= FIRE_MAX; i++ ){

						 if (counter_fires[i].expired==0 &&
							distanceBetweenPoints(game->ship.x,game->ship.y,counter_fires[i].x,counter_fires[i].y) < game->ship.r)
						 {
							 counter_fires[i].expired=1;
							 if(!game->cheats) {
								 game->ShipLives--;
							 }
					         shot=1 ;
					 	}
					 }
		 }
		 else if (s==1){ //multiplayer mode
			 for (int i=0;i <= FIRE_OPP_MAX; i++ ){

				 if (counter_fires[i].expired==0 &&
					distanceBetweenPoints(game->ship.x,game->ship.y,counter_fires[i].x,counter_fires[i].y) < game->ship.r)
				 {
					 counter_fires[i].expired=1;

						 game->ShipLives--; //ship ShipLives

					 game->SaucerScore=game->SaucerScore+1000;
					 shot=1 ;
				}
			 }
		 }


  }

	 return shot;
}


/** Destroys the big roid and splits it in 2 small ones
 * if it is big enough else make it disappear.
    *  @param struct game.
    *   @param index of the roid being hit by laser.
    *    @param struct roids.
    */
void destroyroid(struct Game *game,struct roid roids[],int index){
	 srand(ADC_GetConversionValue(ESPL_ADC_Joystick_2));
            float x = roids[index].x;
            float y = roids[index].y;
            float r = roids[index].r;

            // split big asteroid
            if (r == (ROID_SIZE / 2)) { // large asteroid
            	roids[index].r=(ROID_SIZE / 4);
            	roids[index].xv=(1.5*ROID_SPD)/ CONST ;
            	roids[index].yv=(1.5*ROID_SPD)/ CONST ;


            	int k=0;
            	 while(roids[k].dead==0 && (k< ROID_NUM -1)){
            	     k=k+1;
            	}
            	   roids[k].r=(ROID_SIZE / 4);
            	   roids[k].x=x+40;
            	   roids[k].y=y+40;
            	   roids[k].a=roids[index].a;
            	   roids[k].dead=0;
            	   roids[k].xv=(1.5*ROID_SPD)/ CONST ;
            	   roids[k].yv=(1.5*ROID_SPD)/ CONST ;
            	   roids[k].vert= (rand() % 7) + 3;

            	   for (int  l = 0; l < roids[k].vert; l++) {
            		   // ((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);
            	   		//roids[k].offs[l]=roids[index].offs[l];
            		   roids[k].offs[l]=((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);

            	   }
            }

            // destroy the asteroid when it is small
            else if(r == (ROID_SIZE / 4)){
            	roids[index].dead=1;
            }

}

/** Checks for collision between Saucer and ship.
	*@returns 1 if they  smash
	* else 0
    *  @param struct game.
    */
int collisionSaucerShip (struct Game *game){
	int collision =0 ;

	if (game->mode==SINGLE_MODE) {
		if (!game->saucer.dead) {
			if (distanceBetweenPoints(game->saucer.x,game->saucer.y,game->ship.x,game->ship.y )
					                   < game->saucer.r1+game->ship.r )
			{
				collision=1;
			}
		}
	}
	else  if (game->mode==MULTIPLAYER_MODE) {
		if (distanceBetweenPoints(game->saucer.x,game->saucer.y,game->ship.x,game->ship.y )
				< game->saucer.r1+game->ship.r )
		{
			collision=1;
    	  }
	}

	return collision;
}//collisionSaucerShip
