/**
 * @file game.h
 * @authors Roua Mokchah, Salma Mrabet
 * @date WS 2019/2020
 * */
#ifndef DRAW_GAME_H
#define DRAW_GAME_H

/** @brief this file includes all the functions that are used
 * to draw the saucer, draw the ship , thrust them, shoot und check for the
 * collision.
 */

/** Updates the position of the ship.
 * @param struct game.
 */
//void thrustShip(struct Game *game);
void thrustShip(struct Game *game,char pressed);

/** Makes the ship and saucer spawn around the display
 * @param struct game.
 */
void handleEdgeOfScreen(struct Game *game);

/** Creates new ship.
 * @param struct game.
 * @param x,y for the position of the center of the ship
 * @param color which is usual white
 */
void newShip(struct Game *game,float x,float y,float a,color_t color);

/** Updates the angle of the ship
     *  @param game struct
	 *  @param x and y coordinates of the joystick.
     */
void updateShipAngle(struct Game *game, int16_t joyX,int16_t joyY);

/** Intializes and draws the saucer.
     *  @param struct game.
	 * @param integer s to specify which saucer to draw.
	 * if s=1, mutiplayer mode
	 * if s=0, single player mode.
     */
void newSaucer(struct Game *game,int s);

/** moves the saucer.
     * @param struct game.
	 * @param integer s to specify which saucer to draw.
	 * if s=1, mutiplayer mode
	 * if s=0, single player mode.
     */
void moveSaucer (struct Game *game,int s );

/** Destroys the saucer
    *  @param struct game.
    */
void destroySaucer(struct Game *game);

/** Checks for collision between laser
	* from the ship and the saucer
     *   @param game struct
	 *   @param laser struct
	 *  @param integer s to specify which saucer to draw.
	 * if s=1, mutiplayer mode
	 * if s=0, single player mode.
     */
int collisionLaserSaucer (struct Game *game,struct laser lasers[],int s);

/** Updates the angle of the saucer
	* during the multiplayer mode
     *  @param game struct
	 *  @param x and y coordinates of the joystick.
     */
void updateSaucerAngle(struct Game *game, int16_t joyX,int16_t joyY);

/** Creates fire from saucer
	* when the button is pressed during multiplayer mode
	* or automatically during single player mode
    */
void createFireFromSaucer(struct Game *game,int s, struct fire counter_fires[]);

/** Draws the fire, small circles on the display.
    */
void drawFire(struct fire counter_fires[],struct Game *game,int s);

/** Checks for collision between fire and ship.
	*@returns 1 if the ship was shot.
	* else 0
    *  @param struct game.
    */
int collisionFireShip (struct Game *game,struct fire counter_fires[],int s);

/** Checks for collision between Saucer and ship.
	*@returns 1 if they  smash
	* else 0
    *  @param struct game.
    */
int collisionSaucerShip (struct Game *game);

/*
 * Creates the big roids for each level.
 *  @param struct game.
 *   @param struct roids.
 *    @param value for srand so that during the multiplayer
 *    game both screen have the same shapes of roids.
 */
void createAsteroid(struct roid roids[],struct Game *game,int level,unsigned char value);

/*
 * Creates the laser struct
 *  @param struct game.
 *   @param struct lasers.
 */
void createLaser(struct Game *game, struct laser lasers[]);
/*
 * Draws the laser when the button is pressed
 *   @param struct lasers.
 */
void drawLaser(struct laser lasers[]);

/** Checks for collision between Saucer and roids
 * during the multiplayer mode.
    *  @param struct game.
    *   @param struct fire.
    *    @param struct roids.
    */
void saucerRoid(struct Game *game,struct fire counter_fires[],struct roid roids[]);

/** Calculates the distance between different objects.
    */
float distanceBetweenPoints(float x1,float y1,float x2,float y2);

/** Destroys the big roid and splits it in 2 small ones
 * if it is big enough else make it disappear.
    *  @param struct game.
    *   @param index of the roid being hit by laser.
    *    @param struct roids.
    */
void destroyroid(struct Game *game,struct roid roids[],int index);

/** Checks for collision between laser and roids
 * during the multiplayer mode.
    *  @param struct game.
    *   @param struct lasers.
    *    @param struct roids.
    */
void detectLaser( struct Game *game,struct laser lasers[],struct roid roids[]);

/**Initializes new Level
 * during the multiplayer mode.
    *  @param struct game.
    *    @param struct roids.
    */
void  newLevel(struct Game *game,struct roid roids[]);

/**Initializes new Game
 * during the multiplayer mode.
    *  @param struct game.
    *    @param struct roids.
    */
void  newGame(struct Game *game,struct roid roids[]);


#endif


