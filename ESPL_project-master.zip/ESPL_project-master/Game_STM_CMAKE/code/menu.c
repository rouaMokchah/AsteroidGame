/**
 * @file menu.c
 * @authors Roua Mokchah, Salma Mrabet
 * @date WS 2019/2020
 * */

#include "includes.h"

 /** Initiates the background of the menu.
     *  @param struct roid for drawing different shapes.
     */

void initBackground(struct roid roids[]){

	srand(ADC_GetConversionValue(ESPL_ADC_Joystick_1));

	roids[0].vert= 5;
	roids[0].a= 0.52* PI * 2;
	roids[0].r= 23;
	roids[0].x = 46;
	roids[0].y = 46;

	for (int  j = 0; j < roids[0].vert; j++) {
						roids[0].offs[j]=((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);
					   }

		roids[2].vert= 9;
		roids[2].a= 0.35* PI * 2;
		roids[2].r= 25;
		roids[2].x = 46;
		roids[2].y = 190;

		for (int  j = 0; j < roids[2].vert; j++) {
		roids[2].offs[j]=((rand()%9)/10 * ROID_JAG * 2 + 1 - ROID_JAG);
									   }

			roids[1].vert= 7;
			roids[1].a= 0.8* PI * 2;
			roids[1].r= 30;
			roids[1].x = 46;
			roids[1].y = 130;
			for (int  j = 0; j < roids[1].vert; j++) {
			roids[1].offs[j]=((rand()%6)/10 * ROID_JAG * 2 + 1 - ROID_JAG);
			}

			roids[3].vert= 13;
			roids[3].a= 0.1* PI * 2;
			roids[3].r= 35;
			roids[3].x = 110;
			roids[3].y = 25;
			for (int  j = 0; j < roids[3].vert; j++) {
			roids[3].offs[j]=((rand()%7)/10 * 0.9 * 2 + 1 - 0.9);
							   }

			roids[4].vert= 6;
			roids[4].a= 0.78* PI * 2;
			roids[4].r= 40;
			roids[4].x = 170;
			roids[4].y = 30;
			for (int  j = 0; j < roids[4].vert; j++) {
			roids[4].offs[j]=(0.357 * 0.9 * 2 + 1 - 0.9);
							   }

			roids[5].vert= 5;
			roids[5].a= 0.78* PI * 2;
			roids[5].r= 20;
			roids[5].x = 250;
			roids[5].y = 50;
			for (int  j = 0; j < roids[5].vert; j++) {
			roids[5].offs[j]=(0.98 * 0.9 * 2 + 1 - 0.9);
							   }


}

/** Draws the background of the menu.
    *  @param struct roid for drawing different shapes.
    */

void drawBackGround(struct roid roids[]){

	float _x1,_y1,_x2,_y2;

	for (int i = 0; i < 6 ; i++) {

			 _x1= roids[i].x + roids[i].r * roids[i].offs[0] * cos(roids[i].a);
			 _y1= roids[i].y + roids[i].r * roids[i].offs[0] * sin(roids[i].a);

			// save the first x and y (where to start drawing)
			float prev1=_x1, prev2=_y1;

			// draw the polygon
			for (int j = 1; j < roids[i].vert; j++) {

			 _x2=  roids[i].x + roids[i].r * roids[0].offs[j] * cos(roids[i].a + j * PI * 2 / roids[i].vert);
			 _y2=  roids[i].y + roids[i].r * roids[0].offs[j] * sin(roids[i].a + j * PI * 2 / roids[i].vert);

			gdispDrawLine(prev1,prev2,_x2,_y2,White);
			prev1=_x2;prev2=_y2;
			}
			// this is supposed to close the path, between first points and last
			gdispDrawLine(prev1,prev2,_x1,_y1,White);
}
}

