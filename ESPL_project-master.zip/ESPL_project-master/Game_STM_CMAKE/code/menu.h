/**
 * @file menu.h
 * @authors Roua Mokchah, Salma Mrabet
 * @date WS 2019/2020
 * */

#ifndef MENU_H
#define MENU_H

/** @brief draws the background of the menu.
 */

 /** Initiates the background of the menu.
 *  @param struct roid for drawing different shapes.
 */

void initBackground(struct roid roids[]);

/** Draws the background of the menu.
    *  @param struct roid for drawing different shapes.
    */
void drawBackGround(struct roid roids[]);

#endif
