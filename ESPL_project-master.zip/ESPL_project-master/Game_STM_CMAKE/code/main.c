/**
 * @file main.c
 * @authors Roua Mokchah, Salma Mrabet
 * @date WS 2019/2020
 * */

#include "includes.h"

SemaphoreHandle_t ESPL_DisplayReady;
SemaphoreHandle_t draw_ready_sema;
SemaphoreHandle_t reset_sema;
SemaphoreHandle_t ship_request;
SemaphoreHandle_t saucer_request;
SemaphoreHandle_t you_paused_sema;
SemaphoreHandle_t opp_paused_sema;
SemaphoreHandle_t you_ended_sema;
SemaphoreHandle_t opp_ended_sema;
SemaphoreHandle_t reset_mode_sema;
SemaphoreHandle_t conx_lost_sema;
SemaphoreHandle_t cheats_sema;

TaskHandle_t pauseGameHandle;
TaskHandle_t receiveHandle;
TaskHandle_t stateMachineHandle;
TaskHandle_t frameSwapHandle;
TaskHandle_t drawGameHandle;
TaskHandle_t uartHandle;
TaskHandle_t startMenuHandle;
TaskHandle_t endGameHandle;
TaskHandle_t exitGameHandle;
TaskHandle_t cheatsHandle;
TaskHandle_t highScoreHandle;

QueueHandle_t ButtonList;
QueueHandle_t ButtonListOpp;
QueueHandle_t StateQueue;

void changeState(volatile unsigned char *state, unsigned char forwards);
void frameSwapTask(void * params);
void checkButtons(void * params);
void basicStateMachine(void * params);
void uartReceive();
void sendPosition(buttons buttonStatus);

void drawGame(void *pvParameters);
void startMenu(void *pvParameters);
void exitGame(void *pvParameters);
void endGame(void *pvParameters);
void pauseGame(void *pvParameters);
void highScoreTask(void *pvParameters);
void cheatsGame(void *pvParameters);

struct Game game;
struct roid roid;

int main(void) {

	// Initialize Board functions and graphics
	ESPL_SystemInit();

	// Initialize Semaphores
	draw_ready_sema = xSemaphoreCreateBinary();
	ESPL_DisplayReady = xSemaphoreCreateBinary();
	reset_sema = xSemaphoreCreateBinary();
	ship_request = xSemaphoreCreateBinary();
	saucer_request = xSemaphoreCreateBinary();
	you_paused_sema = xSemaphoreCreateBinary();
	opp_paused_sema = xSemaphoreCreateBinary();
	you_ended_sema = xSemaphoreCreateBinary();
	opp_ended_sema = xSemaphoreCreateBinary();
	reset_mode_sema = xSemaphoreCreateBinary();
	conx_lost_sema = xSemaphoreCreateBinary();
	cheats_sema = xSemaphoreCreateBinary();
	//Initialize Queues
	ButtonList = xQueueCreate(BUTTON_QUEUE_LENGTH, sizeof(buttons));
	ButtonListOpp = xQueueCreate(BUTTON_QUEUE_LENGTH, sizeof(buttons));
	StateQueue = xQueueCreate(STATE_QUEUE_LENGTH, sizeof(unsigned char));

	//Initialize the game struct
	game.ship.x = displaySizeX / 2 - 10;
	game.ship.y = displaySizeY / 2;
	game.ship.r = 5;
	game.ship.angle = 90 * (PI / 180);
	game.ShipLives = GAME_LIVES;
	game.b = 0;
	game.mode = SINGLE_MODE;
	game.ShipScore = 0;
	game.SaucerScore = 0;
	game.level = 0;
	game.SaucerLives = GAME_LIVES;
	//saucer
	game.saucer.x = displaySizeX / 4;
	game.saucer.y = displaySizeY / 4;
	game.saucer.r1 = 12;
	game.saucer.r2 = 20;
	game.saucer.dead = 0;
	game.saucer.a = 90 * (PI / 180);
	game.saucer.thrust.x = 0;
	game.saucer.thrust.y = 0;
	game.HighScore.SingleHighScore = 0;
	game.HighScore.MultiHighScore = 0;
	game.cheats = 0;

	// Initializes Tasks with their respective priority
	xTaskCreate(checkButtons, "checkButtons", 1000, NULL, 3, NULL);
	xTaskCreate(frameSwapTask, "frameSwapper", 1000, NULL, 5, &frameSwapHandle);
	xTaskCreate(uartReceive, "uartReceive", 1000, NULL, 5, &uartHandle);
	xTaskCreate(basicStateMachine, "StateMachine", 1000, NULL, 3,
			&stateMachineHandle);

	xTaskCreate(startMenu, "startMenu", 1000, (void *) &game, 2,
			&startMenuHandle);
	xTaskCreate(pauseGame, "pauseGame", 1000, (void *) &game, 2,
			&pauseGameHandle);
	xTaskCreate(exitGame, "exitGame", 500, (void *) &game, 2, &exitGameHandle);
	xTaskCreate(endGame, "endGame", 1000, (void *) &game, 2, &endGameHandle);

	xTaskCreate(drawGame, "drawGame", STACK_SIZE, (void *) &game, 2,
			&drawGameHandle);
	xTaskCreate(cheatsGame, "cheats", 1000, (void *) &game, 2, &cheatsHandle);
	xTaskCreate(highScoreTask, "highScoreTask", 1000, (void *) &game, 2,
			&highScoreHandle);

	//suspend all the tasks
	vTaskSuspend(drawGameHandle);
	vTaskSuspend(cheatsHandle);
	vTaskSuspend(pauseGameHandle);
	vTaskSuspend(exitGameHandle);
	vTaskSuspend(endGameHandle);
	vTaskSuspend(startMenuHandle);
	vTaskSuspend(highScoreHandle);

	// Start FreeRTOS Scheduler
	vTaskStartScheduler();
}
/*
 * state1: start menu
 * state2: start game
 * state3: pause game
 * state 4 : end game
 * state 5 : cheats
 * state 6 : highscore
 */
void changeState(volatile unsigned char *state, unsigned char forwards) {

	switch (forwards) {
	case 0: //start menu
		*state = 1;
		break;
	case 1: // start game

		*state = 2;
		break;
	case 2: // pause

		*state = 3;
		break;
	case 3: // exit game
		*state = 4;
		break;
	case 4: //  game OVER
		*state = 5;
		break;
	case 5: // cheats
		*state = 6;
		break;
	case 6: // HIGHSCORE
		*state = 7;
		break;

	default:
		break;
	}
}

/*
 * Frame swapping happens in the background, seperate to all other system tasks.
 * This way it can be guarenteed that the 50fps requirement of the system
 * can be met.
 */
void frameSwapTask(void * params) {
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	const TickType_t frameratePeriod = 20;

	while (1) {

		// Draw next frame
		xSemaphoreGive(draw_ready_sema);
		// Wait for display to stop writing
		xSemaphoreTake(ESPL_DisplayReady, portMAX_DELAY);
		// Swap buffers
		ESPL_DrawLayer();

		vTaskDelayUntil(&xLastWakeTime, frameratePeriod);
	}
}

/*
 * Example basic state machine with sequential states
 */
void basicStateMachine(void * params) {
	unsigned char current_state = 1; // Default state
	unsigned char state_changed = 1; // Only re-evaluate state if it has changed
	unsigned char input = 0;

	while (1) {

		if (state_changed)
			goto initial_state;

		// Handle state machine input
		if (xQueueReceive(StateQueue, &input, portMAX_DELAY) == pdTRUE) {
			if (input == START_MENU) {
				changeState(&current_state, 0);
				state_changed = 1;
			} else if (input == START_GAME) {
				changeState(&current_state, 1);
				state_changed = 1;
			} else if (input == PAUSE_GAME) {
				changeState(&current_state, 2);
				state_changed = 1;
			} else if (input == EXIT_GAME) {
				changeState(&current_state, 3);
				state_changed = 1;
			} else if (input == END_GAME) {
				changeState(&current_state, 4);
				state_changed = 1;
			} else if (input == CHEATS) {
				changeState(&current_state, 5);
				state_changed = 1;
			} else if (input == HIGH_SCORE) {
				changeState(&current_state, 6);
				state_changed = 1;
			}
		}

		initial_state:
		// Handle current state
		if (state_changed) {
			switch (current_state) {
			case STATE_ONE: // start_menu
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(cheatsHandle);
				vTaskSuspend(highScoreHandle);

				vTaskResume(startMenuHandle);
				state_changed = 0;
				break;

			case STATE_TWO: //draw game
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(cheatsHandle);
				vTaskSuspend(highScoreHandle);

				vTaskResume(drawGameHandle);

				state_changed = 0;
				break;

			case STATE_THREE: //pause_game
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(cheatsHandle);
				vTaskSuspend(highScoreHandle);

				vTaskResume(pauseGameHandle);

				state_changed = 0;
				break;
			case STATE_FOUR: //EXIT GAME
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(cheatsHandle);
				vTaskSuspend(highScoreHandle);

				vTaskResume(exitGameHandle);

				state_changed = 0;
				break;

			case STATE_FIVE: //END GAME
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(cheatsHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(highScoreHandle);

				vTaskResume(endGameHandle);
				state_changed = 0;
				break;
			case STATE_SIX: //CHEATS
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(highScoreHandle);
				vTaskResume(cheatsHandle);
				state_changed = 0;
				break;
			case STATE_SEVEN: //highscore
				vTaskSuspend(drawGameHandle);
				vTaskSuspend(startMenuHandle);
				vTaskSuspend(pauseGameHandle);
				vTaskSuspend(exitGameHandle);
				vTaskSuspend(endGameHandle);
				vTaskSuspend(cheatsHandle);

				vTaskResume(highScoreHandle);
				state_changed = 0;
				break;

			default:
				break;
			}
		}
	}
}

/**
 * THIS TASK IS CALLED WHEN THE GAME IS OVER
 * Displays who won,lost and which score.
 */

void endGame(void *pvParameters) {
	struct Game *game = (struct Game*) pvParameters;
	buttons buttonStatus = { { 0 } };
	font_t font2 = gdispOpenFont("LargeNumbers");
	char str[100], str2[100], str4[100], str5[100]; // buffer for messages to draw to display
	//signals
	const unsigned char START_MENU_SIGNAL = START_MENU;

	while (TRUE) {

		buttons buttonStatusUART = { { 0 } };
		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;

			gdispClear(Black);
			// press E to go back to the menu
			if (buttonStatus.E || buttonStatusUART.E) {
				xSemaphoreGive(reset_mode_sema);
				xSemaphoreGive(reset_sema);
				xQueueSend(StateQueue, &START_MENU_SIGNAL, 100);
			}

			if (game->mode == SINGLE_MODE) {
				if (game->ShipLives == 0 && game->level != 3) {
					sprintf(str, "GAME OVER ");
					sprintf(str5, "YOUR SCORE IS %d ", game->ShipScore);
					sprintf(str2, "YOU LOST ");
				} else if (game->ShipLives >= 0 && game->level == 0) {

					sprintf(str, "YOU WON");
					sprintf(str2, "GOOD JOB..");
					sprintf(str5, "YOUR SCORE IS %d ", game->ShipScore);
				}
			}
			if (game->mode == MULTIPLAYER_MODE) {

				if (game->ShipLives == 0 && game->SaucerLives > 0
						&& game->SaucerScore > 0) {

					sprintf(str, "THE SAUCER PLAYER WON");
					sprintf(str2, "SEE YOU SOON");
					sprintf(str5, "SAUCER SCORE IS %d ", game->SaucerScore);

				} else if (game->ShipLives > 0 && game->SaucerLives == 0
						&& game->ShipScore > 0) {

					sprintf(str, "THE SHIP PLAYER WON");
					sprintf(str2, "SEE YOU SOON");
					sprintf(str5, "SHIP SCORE IS %d ", game->ShipScore);

				} else {

					sprintf(str, "GAME OVER");
					sprintf(str2, "SEE YOU SOON");
					sprintf(str5, "SHIP SCORE IS %d SAUCER SCORE %d",
							game->ShipScore, game->SaucerScore);
				}
			}

			sprintf(str4, "PRESS E TO GO BACK TO THE MENU..");
			gdispDrawString(110, 140, str4, font2, White);
			gdispDrawString(80, 110, str5, font2, White);
			gdispDrawString(20, 50, str, font2, White);
			gdispDrawString(50, 80, str2, font2, White);
			gdispFillCircle(190, 200, 2, White);
			gdispFillCircle(210, 200, 2, White);
			gdispFillCircle(230, 200, 2, White);

		}
	}
}

/**
 * Task that draws multiplayer Highscores on the display.
 */
void highScoreTask(void *pvParameters) {
	// buffers for messages to draw to display
	char str6[100], str7[100], str8[100], str9[100], str10[100];
	buttons buttonStatus = { { 0 } };
	struct Game *game = (struct Game*) pvParameters;
	//signals
	const unsigned char START_MENU_SIGNAL = START_MENU;
	struct roid roids[6];
	font_t font2 = gdispOpenFont("LargeNumbers");
	//draw the background of the state
	initBackground(roids);

	while (TRUE) {
		buttons buttonStatusUART = { { 0 } };
		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;
			gdispClear(Black);
			drawBackGround(roids);
			// press E to go back to the menu
			if (buttonStatus.E || buttonStatusUART.E) {
				xQueueSend(StateQueue, &START_MENU_SIGNAL, 100);
			}
			sprintf(str6, "MULTIPLAYER HIGHSCORE");
			sprintf(str7, "%d", game->HighScore.MultiHighScore);
			sprintf(str8, "SINGLE HIGHSCORE");
			sprintf(str9, "%d", game->HighScore.SingleHighScore);
			sprintf(str10, "PRESS E TO GO BACK TO THE MENU..");
			gdispDrawString(100, 100, str6, font2, White);
			gdispDrawString(250, 100, str7, font2, White);
			gdispDrawString(100, 140, str8, font2, White);
			gdispDrawString(240, 140, str9, font2, White);
			gdispDrawString(100, 170, str10, font2, White);
		}
	}
}		//highScoreTask
/**
 * This task displays the menu.
 * It is the first things that shows up when booting up.
 */
void startMenu(void *pvParameters) {
	struct Game *game = (struct Game*) pvParameters;
	buttons buttonStatus = { { 0 } };
	font_t font2 = gdispOpenFont("LargeNumbers");
	// buffers for messages to draw to display
	char str[100], str1[100], str2[100], str3[100], str4[100];

	//signals
	const unsigned char START_GAME_SIGNAL = START_GAME;
	const unsigned char HIGH_SCORE_SIGNAL = HIGH_SCORE;
	const unsigned char CHEATS_SIGNAL = CHEATS;
	struct roid roids[6];

	//Background icons

	initBackground(roids);
	//counters to move the circle up and down
	int countA = 0, countC = 0;
	int x1 = 155, y1 = 131, y_prev = 131;

	while (TRUE) {
		buttons buttonStatusUART = { { 0 } };

		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;
			//clear the display.
			gdispClear(Black);
			drawBackGround(roids);
			sprintf(str, "ASTEROIDS");
			gdispDrawString(100, 100, str, font2, White);

			sprintf(str1, "SINGLE PLAYER");
			gdispDrawString(160, 130, str1, font2, White);

			sprintf(str2, "MULTI PLAYER");
			gdispDrawString(160, 160, str2, font2, White);

			sprintf(str3, "HIGHSCORE");
			gdispDrawString(160, 190, str3, font2, White);
			sprintf(str4, "CHEATS");
			gdispDrawString(160, 220, str4, font2, White);

			gdispFillCircle(x1, y_prev, 2, White);

			// single player mode.
			if (buttonStatus.B && y_prev == 131) {
				game->value = buttonStatus.randValue;
				xSemaphoreGive(reset_sema);
				xQueueSend(StateQueue, &START_GAME_SIGNAL, 100);
			}
			// highscore
			if (buttonStatus.B && y_prev == 191) {
				xQueueSend(StateQueue, &HIGH_SCORE_SIGNAL, 100);
			}
			// MULTIplayer
			if (buttonStatus.B && y_prev == 161) {
				if (buttonStatus.shipPlayer == 0
						&& buttonStatusUART.shipPlayer == 0) {
					xSemaphoreGive(ship_request);
				} else if (buttonStatus.saucerPlayer == 0
						&& buttonStatusUART.saucerPlayer == 0) {
					xSemaphoreGive(saucer_request);
				}
				if (buttonStatus.server == 0 && buttonStatusUART.server == 0)
					buttonStatus.server = 1;
				else if (buttonStatus.server == 0
						&& buttonStatusUART.server == 1)
					buttonStatus.server = 2;

			}

			//if the 2 players are ready,start the multiplayer game.
			if ((buttonStatus.shipPlayer == 1
					&& buttonStatusUART.saucerPlayer == 1
					&& buttonStatusUART.shipPlayer == 0
					&& buttonStatus.saucerPlayer == 0)
					|| (buttonStatusUART.shipPlayer == 1
							&& buttonStatus.saucerPlayer == 1
							&& buttonStatus.shipPlayer == 0
							&& buttonStatusUART.saucerPlayer == 0)) {
				if (buttonStatus.server == 1) {
					game->value = buttonStatus.randValue;
				} else if (buttonStatusUART.server == 1) {
					game->value = buttonStatusUART.randValue;
				}
				game->mode = MULTIPLAYER_MODE;
				xSemaphoreGive(reset_sema);
				xQueueSend(StateQueue, &START_GAME_SIGNAL, 100);
			}
			//cheats options
			if (buttonStatus.B && y_prev == 221) {
				xQueueSend(StateQueue, &CHEATS_SIGNAL, 100);
			}
			//button A is used to navigate between the options in the menu
			if (buttonStatus.A) {		//move up
				countA++;
				if (y1 == 161 && countA % 2 == 1 && countA > 0) { // Multiplayer -> Single
					y1 = 131;
					y_prev = y1;
				} else if (y1 == 191 && countA % 2 == 1 && countA > 0) { // highscore -> Single
					y1 = 161;
					y_prev = y1;
				} else if (y1 == 191 && countA % 2 == 0 && countA > 0) { // highscore -> Multiplayer
					y1 = 131;
					y_prev = y1;
				} else if (y1 == 221 && countA % 2 == 0 && countA > 0) { // highscore -> Single
					y1 = 191;
					y_prev = y1;
				}

			}
			//button C is used to navigate between the options in the menu
			if (buttonStatus.C) { //move down
				countC++;
				if (y1 == 131 && countC % 2 == 1) { // Single player -> Multiplayer
					y1 = 161;
					y_prev = y1;
				} else if (y1 == 131 && countC % 2 == 0 && countC > 0) { // Single player -> Exit
					y1 = 191;
					y_prev = y1;
				} else if (y1 == 161 && countC % 2 == 1 && countC > 0) { // Multiplayer -> Exit
					y1 = 191;
					y_prev = y1;
				} else if (y1 == 191 && countC % 2 == 1 && countC > 0) { // highscore -> cheats
					y1 = 221;
					y_prev = y1;
				}
			}

		}
	}
}
/**
 * This task is called when the player pauses the game
 * Both in multi and single modes
 *
 */
void pauseGame(void *pvParameters) {
	font_t font2 = gdispOpenFont("LargeNumbers");
	buttons buttonStatus = { { 0 } };
	char str[100], str2[100], str3[100], str5[100]; // buffer for messages to draw to display
	//signals
	const unsigned char START_GAME_SIGNAL = START_GAME;
	const unsigned char EXIT_GAME_SIGNAL = EXIT_GAME;
	struct Game *game = (struct Game*) pvParameters;

	struct roid roids[6];
	initBackground(roids);

	while (TRUE) {

		buttons buttonStatusUART = { { 0 } };
		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;

			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;
			gdispClear(Black);
			drawBackGround(roids);
			// press E to go back to playing
			if (buttonStatus.E || buttonStatusUART.E) {
				//resume
				xQueueSend(StateQueue, &START_GAME_SIGNAL, 100);

			}

			if (game->mode == MULTIPLAYER_MODE) {
				sprintf(str5, " ");
				// press C to end
				if (buttonStatus.C) {
					// you want to end
					xSemaphoreGive(you_ended_sema);
					xSemaphoreGive(reset_mode_sema);
					xSemaphoreGive(reset_sema);
					xQueueSend(StateQueue, &EXIT_GAME_SIGNAL, 100);
				}
				if (buttonStatusUART.C) {
					//the other player wants to end the game
					xSemaphoreGive(opp_ended_sema);
					xSemaphoreGive(reset_mode_sema);
					xSemaphoreGive(reset_sema);
					xQueueSend(StateQueue, &EXIT_GAME_SIGNAL, 100);
				}
				//display which of the 2 players paused the game
				if (xSemaphoreTake(you_paused_sema, 0) == pdTRUE) {
					sprintf(str, "YOU PAUSED THE GAME.");
					sprintf(str2, " ");
				} else if (xSemaphoreTake(opp_paused_sema, 0) == pdTRUE) {
					sprintf(str, "THE OTHER PLAYER PAUSED THE GAME.");
					sprintf(str2, " ");
				} else if (xSemaphoreTake(conx_lost_sema, 0) == pdTRUE) {
					sprintf(str, "Cable removed..");
					sprintf(str2, " ");

				}
				if (buttonStatusUART.active == 1) {
					//cable removed handled
					sprintf(str2, "PRESS E TO RESUME:");
				}
			}

			else if (game->mode == SINGLE_MODE) {
				// press D to reset only in single player mode
				if (buttonStatus.D) {
					if (!game->cheats)	//Restart single game
					{
						xSemaphoreGive(reset_sema);
					} else if (game->cheats)	//Restart single game
					{
						xSemaphoreGive(cheats_sema);
					}
					xQueueSend(StateQueue, &START_GAME_SIGNAL, 100);
				}

				if (buttonStatus.C) {
					// you want to end
					xQueueSend(StateQueue, &EXIT_GAME_SIGNAL, 100);
				}

				sprintf(str, "YOU PAUSED THE GAME.");
				sprintf(str5, "PRESS D TO RESET.");
				sprintf(str2, "PRESS E TO RESUME:");
			}

			sprintf(str3, "PRESS C TO EXIT THE GAME.");

			gdispDrawString(75, 90, str, font2, White);
			gdispDrawString(95, 120, str2, font2, White);
			gdispDrawString(95, 150, str3, font2, White);
			gdispDrawString(95, 180, str5, font2, White);

		}
	}
}
/**
 * This task is called when the cheats option on the menu is chosen.
 * Player can choose the starting score.
 * and the starting level.
 * Ship won't die.
 * Single Player mode only.
 */
void cheatsGame(void *pvParameters) {
	//signals
	const unsigned char START_GAME_SIGNAL = START_GAME;
	buttons buttonStatus = { { 0 } };
	font_t font2 = gdispOpenFont("LargeNumbers");
	//buffers
	char str1[100], str[100];
	int counter_Button_C = 0;
	int counter_Button_A = 0;
	int Flag_Button_A_pressed = 0;
	int Flag_Button_C_pressed = 0;
	struct Game *game = (struct Game*) pvParameters;

	while (TRUE) {

		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {
			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			//clear screen
			gdispClear(Black);
			sprintf(str, "PRESS A TO CHOOSE THE LEVEL MAX LEVEL 3 ");
			gdispDrawString(50, 100, str, font2, White);
			sprintf(str, "LEVEL %d", counter_Button_A);
			gdispDrawString(50, 120, str, font2, White);
			sprintf(str1, "PRESS C TO SET THE SCORE ");
			gdispDrawString(50, 140, str1, font2, White);
			sprintf(str, "SCORE %d", counter_Button_C);
			gdispDrawString(50, 160, str, font2, White);
			sprintf(str1, "PRESS E TO PLAY ");
			gdispDrawString(50, 200, str1, font2, White);
			// LEVEL
			if (GPIO_ReadInputDataBit(ESPL_Register_Button_A, ESPL_Pin_Button_A)
					== 0) {
				Flag_Button_A_pressed = 1;
			}
			if (Flag_Button_A_pressed == 1
					&& GPIO_ReadInputDataBit(ESPL_Register_Button_A,
					ESPL_Pin_Button_A) == 1) {
				Flag_Button_A_pressed = 0;
				if (counter_Button_A < 3) {
					counter_Button_A += 1;
				}
			}
			// SCORE
			if (GPIO_ReadInputDataBit(ESPL_Register_Button_A, ESPL_Pin_Button_C)
					== 0) {
				Flag_Button_C_pressed = 1;
			}
			if (Flag_Button_C_pressed == 1
					&& GPIO_ReadInputDataBit(ESPL_Register_Button_C,
					ESPL_Pin_Button_C) == 1) {
				Flag_Button_C_pressed = 0;
				counter_Button_C += 100;
			}

			if (buttonStatus.E) {
				game->value = buttonStatus.randValue;
				game->ShipScore = counter_Button_C;
				game->level = counter_Button_A - 1;
				game->mode = SINGLE_MODE;
				xSemaphoreGive(cheats_sema);
				xQueueSend(StateQueue, &START_GAME_SIGNAL, 100);
			}
		}
	}
}	//cheats

/**
 * This task draws the exit screen.
 * This is executed when the player wants to end the game.
 */
void exitGame(void *pvParameters) {

	buttons buttonStatus = { { 0 } };
	char str[100], str2[100]; // buffer for messages to draw to display
	//signals
	const unsigned char START_MENU_SIGNAL = START_MENU;
	font_t font2 = gdispOpenFont("LargeNumbers");
	struct Game *game = (struct Game*) pvParameters;
	//struct roid roids[6];
	//initBackground(roids);
	while (TRUE) {

		buttons buttonStatusUART = { { 0 } };
		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;

			// press E to go back to the menu
			if (buttonStatus.E || buttonStatusUART.E) {

				game->mode = SINGLE_MODE;
				xSemaphoreGive(reset_mode_sema);
				xQueueSend(StateQueue, &START_MENU_SIGNAL, 100);
			}

			gdispClear(Black);

			if (game->mode == MULTIPLAYER_MODE) {
				if (xSemaphoreTake(you_ended_sema, 0) == pdTRUE) {
					sprintf(str, "YOU ENDED THE GAME.BYEEEEEEEE !");
				} else if (xSemaphoreTake(opp_ended_sema, 0) == pdTRUE) {
					sprintf(str, "THE OTHER PLAYER ENDED THE GAME.");
				}
			}

			else if (game->mode == SINGLE_MODE) {
				sprintf(str, "BYEEEEEEEE ! THANKS FOR PLAYING.");
			}

			sprintf(str2, "PRESS E TO GO BACK TO THE MENU. ");
			gdispDrawString(75, 90, str, font2, White);
			gdispDrawString(95, 120, str2, font2, White);

			gdispDrawCircle(200, 180, 20, White);
			gdispFillCircle(190, 180, 2, White);
			gdispFillCircle(210, 180, 2, White);

		}
	}
}
/**
 * Task that draws the game on the display.
 * Both modes are included.
 */

void drawGame(void *pvParameters) {

	font_t font1 = gdispOpenFont("DejaVuSans24");
	buttons buttonStatus = { { 0 } };
	uint16_t fps = 0;
	TickType_t xStartTick, xEndTick;

	//signals
	const unsigned char PAUSE_GAME_SIGNAL = PAUSE_GAME;
	const unsigned char END_GAME_SIGNAL = END_GAME;
	// joystick x and y initial positions
	int16_t joyX, joyY, joyXEnemy, joyYEnemy;

	struct Game *game = (struct Game*) pvParameters;
	srand(game->value);
	struct roid roids[ROID_NUM];

	struct laser lasers[LASER_MAX];
	struct fire counter_fires[FIRE_MAX];
	struct fire opp_fires[FIRE_OPP_MAX];

	int scorePrevious = 0;
	char str3[100], str[100];
	// this is needed to draw the asteroids
	float _x1 = 0, _x2 = 0, _y1 = 0, _y2 = 0;

	int bshow_saucer = 0;

	while (1) {
		xStartTick = xTaskGetTickCount();
		buttons buttonStatusUART = { { 0 } };

		if (xSemaphoreTake(draw_ready_sema, portMAX_DELAY) == pdTRUE) {

			while (xQueueReceive(ButtonList, &buttonStatus, 0) == pdTRUE)
				;
			while (xQueueReceive(ButtonListOpp, &buttonStatusUART, 0) == pdTRUE)
				;
			//clear screen
			gdispClear(Black);

			// if button E is pressed START the game WHERE IT STOPPED
			if (buttonStatus.E) {
				//you paused the game
				xSemaphoreGive(you_paused_sema);
				xQueueSend(StateQueue, &PAUSE_GAME_SIGNAL, 100);
			} else if (buttonStatusUART.E) {
				//your opp paused
				xSemaphoreGive(opp_paused_sema);
				xQueueSend(StateQueue, &PAUSE_GAME_SIGNAL, 100);
			}

			// Update the positions of the joystick
			joyX = buttonStatus.joystick.x - 125;
			joyY = -1 * (buttonStatus.joystick.y - 127);

			joyXEnemy = buttonStatusUART.joystick.x - 125;
			joyYEnemy = -1 * (buttonStatusUART.joystick.y - 127);



			if (xSemaphoreTake(cheats_sema, 0) == pdTRUE) {
				game->cheats = 1;
				newGame(game, roids);
				createAsteroid(roids, game, game->level, game->value);

			}
			//Reset the game before starting normal single game
			else if (xSemaphoreTake(reset_sema, 0) == pdTRUE) {
				newGame(game, roids);
				createAsteroid(roids, game, 0, game->value);
				game->cheats = 0;

			}
			drawLaser(lasers);
			if (game->ShipLives > 0) {
				newShip(game, game->ship.x, game->ship.y, game->ship.angle,White);
			}

			//handle edge of screen for the ship
			handleEdgeOfScreen(game);

			if (game->mode == SINGLE_MODE) {

				if (game->HighScore.SingleHighScore < game->ShipScore) {
					game->HighScore.SingleHighScore = game->ShipScore;
				}

				updateShipAngle(game, joyX, joyY);
				thrustShip(game, buttonStatus.D);
				//create the laser object
				if (buttonStatus.A) {
					createLaser(game, lasers);
				}

				// draw ShipScore
				if (!game->cheats) {
					sprintf(str,
							"FPS: %d ShipLives: %d ShipScore: %d Level: %d",
							(int) fps, game->ShipLives, game->ShipScore,
							game->level + 1);
					gdispDrawString(50, 10, str, font1, White);
				} else if (game->cheats) {
					sprintf(str,
							"FPS: %d ShipScore: %d Level: %d Cheating Mode",
							(int) fps, game->ShipScore, game->level + 1);
					gdispDrawString(50, 10, str, font1, White);
				}

				//extra life
				if (game->ShipScore >= scorePrevious + 6000) {
					game->ShipLives = game->ShipLives + 1;
					scorePrevious = game->ShipScore;
				}

				//game over
				if (game->ShipLives == 0 || game->level == 3) {
					// endGame
					game->level = 0;
					for (int i = 0; i < ROID_NUM; i++) {
						roids[i].dead = 1;
					}
					xQueueSend(StateQueue, &END_GAME_SIGNAL, 100);

				}

				// show saucer 2 times every level
				if (game->level == 0 && game->ShipScore >= 1000) {
					bshow_saucer = 1;
				}

				// 0 for bigSaucer and 1 for SmallSaucer
				if (bshow_saucer && (!game->saucer.dead)) {
					newSaucer(game, 0);
					moveSaucer(game, 0);
					createFireFromSaucer(game, 0, counter_fires);
					drawFire(counter_fires, game, 0);
					if (collisionLaserSaucer(game, lasers, 0)
							&& (!game->saucer.dead)) {
						bshow_saucer = 0;
						game->saucer.dead = 1;
					}

				}
				int boo2 = 0;
				if (!game->cheats) {
					//detect collision fire from saucer and ship
					if (collisionFireShip(game, counter_fires, 0)) {
						boo2 = 1;

					}
					if (boo2) {
						game->ShipLives--;

					}
				}
				int boo1 = 0;
				//check for collision between saucer and ship
				if (collisionSaucerShip(game)) {
					bshow_saucer = 0;
					game->saucer.dead = 1;
					if (!game->cheats) {
						boo1 = 1;
					}

				}
				if (boo1) {
					if (!game->cheats) {
						game->ShipLives--;
					}
				}

			}

			else if (game->mode == MULTIPLAYER_MODE) {

				if (buttonStatusUART.active == 0) {
					xSemaphoreGive(conx_lost_sema);
					xQueueSend(StateQueue, &PAUSE_GAME_SIGNAL, 100);
				}
				if (game->HighScore.MultiHighScore < game->ShipScore) {
					game->HighScore.MultiHighScore = game->ShipScore;
				} else if (game->HighScore.MultiHighScore < game->SaucerScore) {
					game->HighScore.MultiHighScore = game->SaucerScore;
				}

				if (buttonStatus.shipPlayer && buttonStatusUART.saucerPlayer) {
					// if i play with the ship and my opponent plays with the Saucer

					newSaucer(game, 1);
					updateShipAngle(game, joyX, joyY);
					updateSaucerAngle(game, joyXEnemy, joyYEnemy);

					// Button D is for thrusting both ship and saucer
					thrustShip(game, buttonStatus.D);
					if (buttonStatusUART.D) {
						moveSaucer(game, 1);
					}

					//laser from ship when i press A

					if (buttonStatus.A) {
						createLaser(game, lasers);
					}

					//fire from saucer when Opp presses A
					if (buttonStatusUART.A) {
						createFireFromSaucer(game, 1, opp_fires);
						//fire from opp saucer
					}
					drawFire(opp_fires, game, 1);
					saucerRoid(game, opp_fires, roids);
					//check for collision bt fire from opp and ship
					collisionFireShip(game, opp_fires, 1);
				}

				else if (buttonStatus.saucerPlayer
						&& buttonStatusUART.shipPlayer) { // if i play with the saucer and my opponent plays with the ship

					newSaucer(game, 1);
					updateSaucerAngle(game, joyX, joyY);
					updateShipAngle(game, joyXEnemy, joyYEnemy);

					if (buttonStatus.D) {
						moveSaucer(game, 1);

					}
					//fire when A is pressed
					if (buttonStatus.A) {
						createFireFromSaucer(game, 1, opp_fires);
					}
					drawFire(opp_fires, game, 1);
					saucerRoid(game, opp_fires, roids);
					//move the ship
					thrustShip(game, buttonStatusUART.D);
					//laser when UART.A is pressed
					if (buttonStatusUART.A) {
						createLaser(game, lasers);
					}
				}

				sprintf(str3,
						" FPS : %d SaucerLives %d Shiplives %d SaucerScore %d ShipScore %d",
						(int) fps, game->SaucerLives, game->ShipLives,
						game->SaucerScore, game->ShipScore);
				gdispDrawString(10, 20, str3, font1, White);

				if (game->ShipLives == 0 || game->SaucerLives == 0) {
					for (int i = 0; i < ROID_NUM; i++) {
						roids[i].dead = 1;
					}
					xQueueSend(StateQueue, &END_GAME_SIGNAL, 100);

				}

			}  //multiplayer


			// Now draw the roids
			game->roidsNumber = -1;
			game->b = 0;

			for (int i = 0; i < ROID_NUM; i++) {

				int boo = 0;
				if (!roids[i].dead) {
					game->roidsNumber = game->roidsNumber + 1;

					// draw the path
					// multiplying the radius with offs, will change the distance from the center to each vertex
					//each vertex should have a different distance from the center
					_x1 = roids[i].x
							+ roids[i].r * roids[i].offs[0] * cos(roids[i].a);
					_y1 = roids[i].y
							+ roids[i].r * roids[i].offs[0] * sin(roids[i].a);

					// save the first x and y (where to start drawing)
					float prev1 = _x1, prev2 = _y1;

					// draw the polygon
					for (int j = 1; j < roids[i].vert; j++) {

						_x2 =roids[i].x+ roids[i].r * roids[0].offs[j]* cos(roids[i].a
										+ j * PI * 2/ roids[i].vert);
						_y2 =roids[i].y+ roids[i].r * roids[0].offs[j]
									* sin(roids[i].a+ j * PI * 2/ roids[i].vert);
						gdispDrawLine(prev1, prev2, _x2, _y2, White);
						prev1 = _x2;
						prev2 = _y2;
					}
					// this is supposed to close the path, between first points and last
					gdispDrawLine(prev1, prev2, _x1, _y1, White);

					//move the asteroid
					roids[i].x += roids[i].xv;
					roids[i].y += roids[i].yv;

					// handle asteroid edge of screen
					if (roids[i].x < 0 - roids[i].r) {
						roids[i].x = displaySizeX + roids[i].r;
					} else if (roids[i].x > displaySizeX + roids[i].r) {
						roids[i].x = 0 - roids[i].r;
					}

					if (roids[i].y < 0 - roids[i].r) {
						roids[i].y = displaySizeY + roids[i].r;
					} else if (roids[i].y > displaySizeY + roids[i].r) {
						roids[i].y = 0 - roids[i].r;
					}

					//check for collision between ship+roid
					// check for collision between Saucer+roid in multiplayer mode
					if (game->mode == MULTIPLAYER_MODE) {
						if (distanceBetweenPoints(game->saucer.x,
								game->saucer.y, roids[i].x, roids[i].y)
								< game->saucer.r1 + roids[i].r) {
							roids[i].dead = 1;
							game->SaucerLives = game->SaucerLives - 1;

						}
					}
					if (distanceBetweenPoints(game->ship.x, game->ship.y,
							roids[i].x, roids[i].y)
							< game->ship.r + roids[i].r) {
						boo = 1;
						roids[i].dead = 1;
					}
					if (boo) {
						if (!game->cheats) {
							game->ShipLives--;
						}
					}
				}
			}
			// detect collision asteroid laser
			detectLaser(game, lasers, roids);

			game->b = 1;
			// new level when all  asteroids are dead && saucer is dead
			if (game->mode == SINGLE_MODE) {
				if ((game->roidsNumber == -1 && game->b) && game->saucer.dead) {
					//reset the saucer to reappear in the new level
					game->saucer.dead = 0;
					bshow_saucer = 1;
					//add new level
					int lev = game->level;
					newLevel(game, roids);
					createAsteroid(roids, game, lev, game->value);
				}
			}
			// new level multiplayer mode
			if (game->mode == MULTIPLAYER_MODE) {
				if ((game->roidsNumber == -1 && game->b)) {
					//add new level
					newLevel(game, roids);
					int lev = game->level;
					createAsteroid(roids, game, lev, game->value);
				}
			}
		}
		xEndTick = xTaskGetTickCount();
		fps = configTICK_RATE_HZ / (xEndTick - xStartTick);

	}
}

/**
 * This task polls the joystick value every 20 ticks
 */
void checkButtons(void * params) {
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	buttons buttonStatus = { { 0 } };
	const TickType_t PollingRate = 20;

	int Apressed = 0, Epressed = 0, Bpressed = 0, Cpressed = 0, Kpressed = 0;

	while (TRUE) {
		// Remember last joystick values
		buttonStatus.joystick.x = (uint8_t) (ADC_GetConversionValue(
		ESPL_ADC_Joystick_2) >> 4);
		buttonStatus.joystick.y = (uint8_t) 255
				- (ADC_GetConversionValue(ESPL_ADC_Joystick_1) >> 4);

		buttonStatus.randValue = ADC_GetConversionValue(ESPL_ADC_Joystick_2);
		// buttonA
		buttonStatus.A = !GPIO_ReadInputDataBit(ESPL_Register_Button_A,
		ESPL_Pin_Button_A);
		if (buttonStatus.A && Apressed) {
			buttonStatus.A = 0;
		} else if (buttonStatus.A && !Apressed) {
			Apressed = 1;

		} else if (!buttonStatus.A && Apressed) {
			Apressed = 0;
		}
		// button B
		buttonStatus.B = !GPIO_ReadInputDataBit(ESPL_Register_Button_B,
		ESPL_Pin_Button_B);
		if (buttonStatus.B && Bpressed) {
			buttonStatus.B = 0;
		} else if (buttonStatus.B && !Bpressed) {
			Bpressed = 1;

		} else if (!buttonStatus.B && Bpressed) {
			Bpressed = 0;
		}
		// button C
		buttonStatus.C = !GPIO_ReadInputDataBit(ESPL_Register_Button_C,
		ESPL_Pin_Button_C);
		if (buttonStatus.C && Cpressed) {
			buttonStatus.C = 0;
		} else if (buttonStatus.C && !Cpressed) {
			Cpressed = 1;

		} else if (!buttonStatus.C && Cpressed) {
			Cpressed = 0;
		}
		// button D
		buttonStatus.D = !GPIO_ReadInputDataBit(ESPL_Register_Button_D,
		ESPL_Pin_Button_D);
		// button E
		buttonStatus.E = !GPIO_ReadInputDataBit(ESPL_Register_Button_E,
		ESPL_Pin_Button_E);
		if (buttonStatus.E && Epressed) {
			buttonStatus.E = 0;
		} else if (buttonStatus.E && !Epressed) {
			Epressed = 1;

		} else if (!buttonStatus.E && Epressed) {
			Epressed = 0;
		}
		//button K
		buttonStatus.K = !GPIO_ReadInputDataBit(ESPL_Register_Button_K,
		ESPL_Pin_Button_K);
		if (buttonStatus.E && Kpressed) {
			buttonStatus.K = 0;
		} else if (buttonStatus.K && !Kpressed) {
			Kpressed = 1;

		} else if (!buttonStatus.K && Kpressed) {
			Kpressed = 0;
		}

		if (xSemaphoreTake(ship_request, 0) == pdTRUE) {
			buttonStatus.shipPlayer = 1;
		}
		if (xSemaphoreTake(reset_mode_sema, 0) == pdTRUE) {
			buttonStatus.shipPlayer = 0;
			buttonStatus.saucerPlayer = 0;
			buttonStatus.server = 0;
		}
		if (xSemaphoreTake(saucer_request, 0) == pdTRUE) {
			buttonStatus.saucerPlayer = 1;
		}
		sendPosition(buttonStatus);

		xQueueSend(ButtonList, &buttonStatus, 100);

		// Execute every 20 Ticks
		vTaskDelayUntil(&xLastWakeTime, PollingRate);
	}
}

/*
 *  Hook definitions needed for FreeRTOS to function.
 */
void vApplicationIdleHook() {
	while (TRUE) {
	};
}

void vApplicationMallocFailedHook() {
	while (TRUE) {

	};
}
/**
 * Example function to send data over UART
 *
 * Sends coordinates of a given position via UART.
 * Structure of a package:
 *  8 bit start byte
 *  8 bit x-coordinate
 *  8 bit y-coordinate
 *  8 bit checksum (= x-coord XOR y-coord)
 *  8 bit stop byte
 */
void sendPosition(buttons buttonStatus) {
	const uint8_t checksum = buttonStatus.joystick.x ^ buttonStatus.joystick.y
			^ buttonStatus.A ^ buttonStatus.B ^ buttonStatus.C ^ buttonStatus.D
			^ buttonStatus.E ^ buttonStatus.K ^ buttonStatus.active
			^ buttonStatus.saucerPlayer ^ buttonStatus.shipPlayer
			^ buttonStatus.randValue ^ buttonStatus.randValue1
			^ buttonStatus.server;

	buttonStatus.active = 1;

	UART_SendData(startByte);
	UART_SendData(buttonStatus.joystick.x);
	UART_SendData(buttonStatus.joystick.y);
	UART_SendData(buttonStatus.A);
	UART_SendData(buttonStatus.B);
	UART_SendData(buttonStatus.C);
	UART_SendData(buttonStatus.D);
	UART_SendData(buttonStatus.E);
	UART_SendData(buttonStatus.K);
	//always send a 1
	// if an uart is connected he will get the 1
	UART_SendData(buttonStatus.active);
	UART_SendData(buttonStatus.saucerPlayer);
	UART_SendData(buttonStatus.shipPlayer);
	UART_SendData(buttonStatus.randValue);
	UART_SendData(buttonStatus.randValue1);
	UART_SendData(buttonStatus.server);
	UART_SendData(checksum);
	UART_SendData(stopByte);
}

/**
 * Example how to receive data over UART (see protocol above)
 */
void uartReceive() {
	char input;
	uint8_t pos = 0;
	char checksum;
	char buffer[16]; // Start byte,4* line byte, checksum (all xor), End byte
	buttons buttonStatus = { { 0 } };
	while (TRUE) {
		// wait for data in queue
		xQueueReceive(ESPL_RxQueue, &input, portMAX_DELAY);

		// decode package by buffer position
		switch (pos) {
		// start byte
		case 0:
			if (input != startByte)
				break;
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
			// read received data in buffer
			buffer[pos] = input;
			pos++;
			break;
		case 16:
			// Check if package is corrupted
			checksum = buffer[1] ^ buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5]
					^ buffer[6] ^ buffer[7] ^ buffer[8] ^ buffer[9] ^ buffer[10]
					^ buffer[11] ^ buffer[12] ^ buffer[13] ^ buffer[14];
			if (input == stopByte || checksum == buffer[15]) {
				// pass position to Joystick Queue
				buttonStatus.joystick.x = buffer[1];
				buttonStatus.joystick.y = buffer[2];
				buttonStatus.A = buffer[3];
				buttonStatus.B = buffer[4];
				buttonStatus.C = buffer[5];
				buttonStatus.D = buffer[6];
				buttonStatus.E = buffer[7];
				buttonStatus.K = buffer[8];
				buttonStatus.active = buffer[9];
				buttonStatus.saucerPlayer = buffer[10];
				buttonStatus.shipPlayer = buffer[11];
				buttonStatus.randValue = buffer[12];
				buttonStatus.randValue1 = buffer[13];
				buttonStatus.server = buffer[14];
				xQueueSend(ButtonListOpp, &buttonStatus, 100);

			}
			pos = 0;
		}
	}
}
